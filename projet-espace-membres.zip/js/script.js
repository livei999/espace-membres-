document.addEventListener('DOMContentLoaded', () => {
    console.log('Espace Membres chargé!');
});
